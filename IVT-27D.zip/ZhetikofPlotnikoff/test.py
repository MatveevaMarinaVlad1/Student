print ('WSub')
print ('nigga')
