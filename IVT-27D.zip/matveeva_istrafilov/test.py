print("hello")
print("my name is ann")
