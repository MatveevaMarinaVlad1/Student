import cv2
import numpy as np

#ishodnik
img0 = cv2.imread('0_1.jpg',0)
img1 = cv2.imread('1.jpg',0)
img2 = cv2.imread('2.jpg',0)
img3 = cv2.imread('3.jpg',0)
img4 = cv2.imread('4.jpg',0)
img5 = cv2.imread('5.jpg',0)
img6 = cv2.imread('6.jpg',0)
img7 = cv2.imread('7.jpg',0)
img8 = cv2.imread('8.jpg',0)
img9 = cv2.imread('9.jpg',0)

#iskazhenie

img51 = cv2.imread('51.jpg',0)

ret,thresh0 = cv2.threshold(img0,70,255,cv2.THRESH_BINARY)
#cv2.imshow("test_window", thresh0)
ret,thresh1 = cv2.threshold(img1,70,255,cv2.THRESH_BINARY)
ret,thresh2 = cv2.threshold(img2,70,255,cv2.THRESH_BINARY)
ret,thresh3 = cv2.threshold(img3,70,255,cv2.THRESH_BINARY)
ret,thresh4 = cv2.threshold(img4,70,255,cv2.THRESH_BINARY)
ret,thresh5 = cv2.threshold(img5,70,255,cv2.THRESH_BINARY)
ret,thresh6 = cv2.threshold(img6,70,255,cv2.THRESH_BINARY)
ret,thresh7 = cv2.threshold(img7,70,255,cv2.THRESH_BINARY)
ret,thresh8 = cv2.threshold(img8,70,255,cv2.THRESH_BINARY)
ret,thresh9 = cv2.threshold(img9,70,255,cv2.THRESH_BINARY)

images = [thresh0, thresh1, thresh2, thresh3, thresh4, thresh5,thresh6,thresh7,thresh8,thresh9]


ret, thresh51 = cv2.threshold(img51, 70, 255,cv2.THRESH_BINARY)
#cv2.imshow("test_window",thresh51)

num0 = thresh0
num1 = thresh1
num2 = thresh2
num3 = thresh3
num4 = thresh4
num5 = thresh5
num6 = thresh6
num7 = thresh7
num8 = thresh8
num9 = thresh9
nums = [num0, num1, num2, num3, num4, num5, num6, num7, num8, num9]

# виды цифры 5(test)

num51 = thresh51

# инициализация весов сети
# weights = [0 for i in range(15)]

weights = []
for i in range(15):
    weights.append(0)

# порог функции активации

bias = 7

# является ли данное число 5

def proceed(number):
    # взвешанная сумма
    net = 0
    for i in range(15):
        net += weights[i]*int(number[i])
    # превышен ли порог? (да - сеть думает, что это 5, нет - другая цифра)
    return net>=bias
    '''if (net>=bias):
        return True
    else
        return False'''
#уменьшение значений весов, если сеть ошиблась и выдала 1
def decrease(number):
    for i in range(15):
        if (int(number[i])==1):
            weights[i] -=1

            
#увеличение значений весов, если сеть ошиблась и выдала 0
def increase(number):
    for i in range(15):
        if (int(number[i])==1):
            weights[i] +=1    

# тренировка сети

for i in range(10000):
    option = random.randint(0,9)

    if (option!=5):
        if (proceed(nums[option])):
            decrease(nums[option])
    else:
        if not proceed(num5):
            increase(num5)
# вывод результатов
print(weights)
#прогон по тестовой выборке
print ("0 это число 5?", proceed(num0))
print ("1 это число 5?", proceed(num1))
print ("2 это число 5?", proceed(num2))
print ("3 это число 5?", proceed(num3))
print ("4 это число 5?", proceed(num4))
print ("6 это число 5?", proceed(num6))
print ("7 это число 5?", proceed(num7))
print ("8 это число 5?", proceed(num8))
print ("9 это число 5?", proceed(num9), "\n")
            
# прогон по обучающей выборке
print ("5 - 5?", proceed(num5))
print ("5 - искаженная 5.1?", proceed(num51))       








cv2.waitKey(0)
cv2.destroyAllWindows()
